# GameBoost Analyzer Pro (Android source project)

## What is included
- Arabic dark UI
- Reads phone manufacturer/model and Android version
- Reads total/available RAM
- Displays supported CPU ABI architectures (not a commercial CPU model name)
- Displays screen resolution, reported refresh rate and system density
- Displays battery percentage when available
- Free Fire sensitivity starting presets and copy button
- DPI information page (does not change system DPI)
- Local-only basic diagnostics; no internet permission

## Build
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync and install the Android SDK platform 35 if prompted.
4. Run on a real Android phone or emulator.
5. To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important limitations
This is a starter project, not a tested/compiled APK. It does not read Free Fire's internal settings or guarantee headshots/FPS. Sensitivity values are illustrative starting presets, not personalized measurements. Android restricts access to some CPU/GPU/thermal information. The project needs testing in Android Studio before distribution.
