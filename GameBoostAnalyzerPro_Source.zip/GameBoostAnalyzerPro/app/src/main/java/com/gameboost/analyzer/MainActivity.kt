package com.gameboost.analyzer

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 18, 26)
    private val card = Color.rgb(28, 34, 46)
    private val accent = Color.rgb(35, 220, 165)
    private val white = Color.rgb(244, 247, 250)
    private val muted = Color.rgb(172, 184, 198)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).roundToInt()

    private fun label(text: String, size: Float, color: Int = white, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(Color.rgb(8, 25, 22))
            setBackgroundColor(accent)
            setOnClickListener { onClick() }
        }
    }

    private fun newPage(title: String): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(18), dp(16), dp(18))
        }
        outer.addView(label("GAMEBOOST ANALYZER PRO", 13f, accent, true))
        outer.addView(label(title, 25f, white, true))
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(20))
        }
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
        return content
    }

    private fun card(title: String, detail: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(card)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        box.addView(label(title, 17f, accent, true))
        box.addView(label(detail, 14f, white))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, dp(10))
        content.addView(box, lp)
    }

    private fun showHome() {
        newPage("فحص هاتفك")
        card("نوع الهاتف", "${Build.MANUFACTURER} ${Build.MODEL}")
        card("إصدار أندرويد", "Android ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}")
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val total = mem.totalMem / 1073741824.0
        val avail = mem.availMem / 1073741824.0
        card("الرامات (RAM)", String.format(Locale.US, "الإجمالي: %.2f GB\nالمتاح حاليًا: %.2f GB", total, avail))
        card("بنية المعالج المتاحة", Build.SUPPORTED_ABIS.joinToString(", "))
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(dm)
        val refresh = if (Build.VERSION.SDK_INT >= 23) windowManager.defaultDisplay.refreshRate else 0f
        card("الشاشة", "${dm.widthPixels} × ${dm.heightPixels} بكسل\nمعدل التحديث المُبلّغ عنه: ${refresh.roundToInt()} Hz\nكثافة النظام: ${dm.densityDpi} dpi")
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        card("البطارية", if (battery in 0..100) "$battery%" else "غير متاحة")
        card("تنبيه مهم", "أندرويد لا يكشف دائمًا الاسم التجاري الدقيق للمعالج أو GPU للتطبيقات العادية. لا تعتبر بنية المعالج اسم المعالج نفسه.")
        content.addView(button("اقتراح حساسية Free Fire") { showSensitivity() })
        content.addView(button("اقتراح DPI") { showDpi() })
        content.addView(button("إعدادات التطبيق") { showSettings() })
        content.addView(button("إعادة الفحص") { showHome() })
    }

    private fun showSensitivity() {
        newPage("حساسية Free Fire")
        card("قبل البدء", "هذه قيم بداية للتجربة وليست إعدادات مثالية مضمونة. مواصفات الهاتف وحدها لا تكفي لتحديد الحساسية المناسبة.")
        card("نمط سريع", "General: 95\nRed Dot: 90\n2x Scope: 85\n4x Scope: 75\nSniper Scope: 50\nFree Look: 80")
        card("نمط متوازن", "General: 90\nRed Dot: 85\n2x Scope: 80\n4x Scope: 70\nSniper Scope: 45\nFree Look: 75")
        card("نمط دقيق", "General: 82\nRed Dot: 78\n2x Scope: 72\n4x Scope: 62\nSniper Scope: 38\nFree Look: 65")
        card("طريقة الاستخدام", "ابدأ بنمط واحد داخل ساحة التدريب، وعدّل القيم تدريجيًا حسب استجابة التصويب. قد تختلف حدود الحساسية حسب إصدار اللعبة.")
        content.addView(button("نسخ القيم المتوازنة") {
            val text = "General 90\\nRed Dot 85\\n2x Scope 80\\n4x Scope 70\\nSniper Scope 45\\nFree Look 75"
            val clip = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clip.setPrimaryClip(android.content.ClipData.newPlainText("Free Fire sensitivity", text))
            Toast.makeText(this, "تم نسخ القيم", Toast.LENGTH_SHORT).show()
        })
        content.addView(button("رجوع للرئيسية") { showHome() })
    }

    private fun showDpi() {
        newPage("اقتراح DPI")
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(dm)
        card("كثافة العرض الحالية", "${dm.densityDpi} dpi")
        card("التوصية", "ابدأ بالكثافة الحالية. لا توجد قيمة DPI مثالية لكل الهواتف، ورفعها لا يضمن هيدشوت أفضل. جرّب إعدادات اللعبة أولًا.")
        card("لماذا لا أغيّرها تلقائيًا؟", "تغيير كثافة العرض قد يصغّر النصوص والأزرار أو يسبب صعوبة في استخدام الهاتف. هذا التطبيق لا يغيّر إعدادات النظام ولا يحتاج إلى Root.")
        content.addView(button("رجوع للرئيسية") { showHome() })
    }

    private fun showSettings() {
        newPage("إعدادات التطبيق")
        card("الخصوصية", "يعمل الفحص محليًا على الهاتف ولا يرسل مواصفاتك إلى خادم خارجي.")
        card("الإصدار", "GameBoost Analyzer Pro 1.0")
        card("حدود الفحص", "المعلومات المعروضة هي ما يسمح أندرويد للتطبيق بقراءته. بعض تفاصيل المعالج وGPU وحرارة الجهاز قد لا تكون متاحة.")
        content.addView(button("رجوع للرئيسية") { showHome() })
    }
}
